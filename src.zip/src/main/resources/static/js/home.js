function welcome(){
    alert('Message');
    console.log("Got to this point");
    elem = document.getElementById("welcome");

    elem.innerHTML="Hi guest"

}

